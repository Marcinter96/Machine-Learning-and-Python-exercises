# ### LSTM Case study

from tensorflow.keras.layers import LSTM, TimeDistributed, Dense, Input
from tensorflow.keras import Model, Sequential
from tensorflow.keras.callbacks import ModelCheckpoint
from tensorflow.keras import models
from tensorflow.keras.models import load_model
import numpy as np
import pandas as pd
from tensorflow.keras import backend as K


# #### About the dataset
# 
# - The dataset for this case study has been simulated manually and stored in input.csv and target.csv file.
# - Each row in the input dataset is a size 1000 and you have total 1000 records. so your input dimension is (1000 x 1000). The columns represent the feature and row are the samples. The input dataset has been provided in input.csv file.
# - The output dataset is based on certain function applied on input data  
#   - input  $X=x_0, x_1, x_2 ...x_{997}, x_{998}, x_{999}$    
#   - output Y[0:10] = 0, Y[10:] is based on some function applied on input X.

"""
complete the functions defined below and in order to test these functions launch 
the jupyter notebook and run the scripts in try_it_out.ipynb.
"""



def read_data(input_file, target_file):
    """reads input and target from input_file and tartget_file and returns 
    tuple(X, y) where X is input of shape (num_samples, sequence_length, num_features)
    and y is of shape (num samples, sequence_length, 1)
    
    Arguments:
        input_file {string} -- input file path in csv
        target_file {string} -- target file path csv format
    """
    X = pd.read_csv(input_file, header=None).values
    y = pd.read_csv(target_file, header=None).values
    X =X.reshape(X.shape[0], X.shape[1], 1)
    y = y.reshape(y.shape[0],y.shape[1],1)
    
    return X,y

    

# #### In this case study you will build an LSTM model to train and predict time series data provide as part of this exercise.
# ### The model should have following specification:
#      - A single layer of LSTM with 5 hidden nodes
#      - A final output layer with single node to predict the output.
# - Use tensorflow.keras to define the layers of the model

def root_mean_squared_error(y_true, y_pred):
        return K.sqrt(K.mean(K.square(y_pred - y_true)))


def lstm_model(num_units, seq_len, num_feature):
    """build and compile a LSTM model using tensorflow.keras with single
       layer of <num_units> hidden units and a final FC layers with one unit.
       compile the model with appropriate loss functions and optimizer and return the
       compiled model.
    
    Arguments:
        num_units {int} -- number of hiiden units in LSTM layer
        seq_len {int} -- sequence length in each input sample
        num_feature {int} -- number of features at each time step of input sequence
    """
    inputs = Input(shape=(seq_len,num_feature))
    hidden = LSTM(num_units, return_sequences=True)(inputs)
    outputs = TimeDistributed(Dense(1))(hidden)
    model = Model(inputs, outputs)


    model.compile(loss=root_mean_squared_error, optimizer='rmsprop')
    return model
   



def train(X, y, model):
    """Using the input X and target y train the model returned by lstm_model() 
    Once the model is trained save the model weights in 'weigts.h5' file.
    
    Arguments:
        X {n-d array} -- input data
        y {n-d array} -- target data
        model -- model define using lstm_model()
    """
    checkpoint_filepath = '/checkpoint'
    model_checkpoint_callback = ModelCheckpoint(
    filepath=checkpoint_filepath,
    save_weights_only=True,
    monitor='val_accuracy',
    mode='max',
    save_best_only=True)
    model.fit(X, y, epochs=30, batch_size=50, shuffle=False, validation_split=0.05, verbose=1, callbacks=[model_checkpoint_callback])
    model.save("weights.h5")
    
   

def predict(input_file, weights_file):
    """
    loads the model from weights_file and run predictions 
    on input read from input_file
    
    Arguments:
        input_file {string} -- input csv file
        weights_file {string} -- model weights file name
    
    Returns:
        [nd-array] -- output in the form of array
    """

    model = model = load_model('weights.h5', compile=False)
    model.compile(loss=root_mean_squared_error, optimizer='rmsprop')
    X_test = pd.read_csv(input_file, header=None).values
    X_test =X_test.reshape(X_test.shape[0], X_test.shape[1], 1)
    preds = model.predict(X_test,batch_size=50, verbose=1)
    return preds


    
    
    


# ### Validation
# - You are given the input files test_inp1.csv and test_inp2.csv and their corresponding target values in   
#   test_tar1.csv and test_tar2.csv
# - Run the predictions on input files and validate against the values in target files
# - The expected rmse value against the predictions on both the input files has to be less than ___   
