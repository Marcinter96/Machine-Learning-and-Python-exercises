#!/usr/bin/env python
# coding: utf-8

# ### In this hands on you will build a model that once trained on a peice of text data can generate its own sequnce of words in a similar fashion as in trained data.
# 
# - Follow the instructions provided for each cell and and code accordingly. 
# - In order to run the cell press shift+enter.
# - make sure you have run all the cells before submitting the hands on

# ### Run the below cell to import necessary packages

# In[1]:


import numpy as np
import pandas as pd
from keras import backend as K
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import LSTM
from keras.utils import np_utils


# ### Read the text data from story.txt file and split the text into seperate tokens, assign thr array of tokens to variable *training_data*
# 
# ### Expected output:
#     array(['long', 'ago', ',', 'the', 'mice', 'had', 'a', 'general',
#        'council', 'to']

# In[2]:


### Start code here
with open('story.txt') as f:
    d =f.readlines()
data = d[0]
training_data = data.split(" ")
###End code
training_data[:10]


# In[3]:


training_data = training_data[:-1]
for i in training_data:
    if i == "":
        training_data.remove(i)


# ### Take the unique tokens in training_data nas sort them alphabetical order and assign the sorted list to variable words
# ### create dictionary ind_to_word to map index to word
# ### create another dictionary word_to_ind to reverse map word to their respective index.

# In[4]:


####Start code here
words = sorted(set(training_data))
ind_to_word = {k: v for v, k in enumerate(words)}
word_to_ind = inv_map = {v: k for k, v in ind_to_word.items()}
###End code
print("words: ", words[:10], "\n")
print("index_to_words: ", list(ind_to_word.items())[:10], "\n")
print("word_to_index: ", list(word_to_ind.items())[:10], "\n")


# ### write a function to generate training dataset 
#     - parameters: dataset: orginal dataset
#                   look_back: the window size that tells the number of previous values in the series to look for to                   predict the next one.
#     - returns: feature and target arrays
#     
# example: 
#          for window size 1:
#          dataset = [1,2,3,4]  
#          feature = [[1],[2],[3]]    
#          target = [2,3,4]  
#          
#          for window size 2:
#          feature = [[1,2],[2,3]]  
#          target = [3,4]  
# ### Expected output when you when you call generate_dataset on training_data and look_back = 10 :
# input:  [[48, 5, 0, 85, 56, 37, 3, 35, 28, 92], [5, 0, 85, 56, 37, 3, 35, 28, 92, 25], [0, 85, 56, 37, 3, 35, 28, 92, 25, 102]]  
# labels:  [25, 102, 53]
# 

# In[5]:


####Start code here
def generate_dataset(dataset, look_back=10):
    dataX = []
    dataY = []
    for i in range(0, len(dataset) - look_back, 1):
        seq_in = dataset[i:i + look_back]
        seq_out = dataset[i + look_back]
        dataX.append([ind_to_word[char] for char in seq_in])
        dataY.append(ind_to_word[seq_out])
    return dataX, dataY

    
###End code

inputs, labels = generate_dataset(training_data, 10)
print("input: ", inputs[:3])
print("labels: ", labels[:3])


# ### Next step is to  reshape the inputs and normalize them.
#     - This step is coded for you
#     - Run the below cell to prepare the data for training the model

# In[6]:


look_back = 10
X_modified = np.reshape(inputs, (len(inputs), look_back, 1))
X_modified = X_modified / float(len(words))
Y_modified = np_utils.to_categorical(labels)


# ### Using keras Sequential() class create a model having two LSTM block and one fully connected  layer with activation softmax
# ### apply dropout with probability p = 0.2 between the layers of LSTM
# ### compile the model with categorical_crossentropy loss and  adam optimizer
# 
# ### Expected output
# <img src="lstm.png">

# In[7]:


np.random.seed(51)
###Start code here
model = Sequential()
model.add(LSTM(400, input_shape=(10,400), return_sequences=True))
model.add(Dropout(0.2))
model.add(LSTM(400))
model.add(Dropout(0.2))
model.add(Dense(112, activation='softmax'))

###End code
model.compile(loss='categorical_crossentropy', optimizer='adam')
model.summary()


# ### Run model.fit() on train data with features as X_modified and target as Y_modified for 50 epoches and batch_size = 10

# In[8]:


###Start code here
train_logs = model.fit(X_modified, Y_modified, epochs=50, batch_size=10) 
###End code
with open("output.txt", "w+") as file:
    file.write("train score {0:.2f}\n".format(train_logs.history["loss"][-1]))


# ### The below codes takes a random sequence of words and generates more sequnce using the model you trained above.

# In[ ]:


string_mapped = inputs[50].copy()
full_string = [ind_to_word[value] for value in string_mapped]
# generating characters
for i in range(100):
    x = np.reshape(string_mapped,(1,len(string_mapped), 1))
    x = x / float(len(words))
    pred_index = np.argmax(model.predict(x, verbose=0))
    seq = [ind_to_word[value] for value in string_mapped]
    full_string.append(ind_to_word[pred_index])

    string_mapped.append(pred_index)
    string_mapped = string_mapped[1:len(string_mapped)]

    
txt=""
for word in full_string:
    txt = txt+" "+word
print(txt)


# In[ ]:




