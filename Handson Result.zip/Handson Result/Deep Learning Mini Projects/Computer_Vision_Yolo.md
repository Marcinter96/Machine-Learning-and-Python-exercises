```python
!pip install opencv-python
```

    Requirement already satisfied: opencv-python in /opt/conda/lib/python3.7/site-packages (4.5.5.62)
    Requirement already satisfied: numpy>=1.14.5; python_version >= "3.7" in /opt/conda/lib/python3.7/site-packages (from opencv-python) (1.19.2)



```python
import numpy as  np
import cv2
from matplotlib import pyplot as plt
import pickle
```


```python
!wget https://hr-projects-assets-prod.s3.amazonaws.com/ebch7d568km/75ff0c7bbdc46102bdce373359d609e4/scene2.jpg -O scene2.jpg
```

    --2022-01-11 13:07:04--  https://hr-projects-assets-prod.s3.amazonaws.com/ebch7d568km/75ff0c7bbdc46102bdce373359d609e4/scene2.jpg
    Resolving hr-projects-assets-prod.s3.amazonaws.com (hr-projects-assets-prod.s3.amazonaws.com)... 54.231.133.153
    Connecting to hr-projects-assets-prod.s3.amazonaws.com (hr-projects-assets-prod.s3.amazonaws.com)|54.231.133.153|:443... connected.
    HTTP request sent, awaiting response... 200 OK
    Length: 375130 (366K) [binary/octet-stream]
    Saving to: ‘scene2.jpg’
    
    scene2.jpg          100%[===================>] 366.34K   354KB/s    in 1.0s    
    
    2022-01-11 13:07:06 (354 KB/s) - ‘scene2.jpg’ saved [375130/375130]
    



```python
# load the image(scene2.jpg) to detect, get width, height 
img_to_detect = cv2.imread('scene2.jpg')
img_height = img_to_detect.shape[0]
img_width = img_to_detect.shape[1]
```


```python
# convert to blob to pass into model using openCV "dnn.blobFromImage"
img_blob = cv2.dnn.blobFromImage(img_to_detect, 1/255.0, (416, 416))
#recommended scale factor is 0.003922=1/255, width,height of blob is 416,416
#accepted sizes are 320×320,416×416,609×609. More size means more accuracy but less speed
```


```python
# set of 80 class labels 
class_labels = ["person","bicycle","car","motorcycle","airplane","bus","train","truck","boat",
                "trafficlight","firehydrant","stopsign","parkingmeter","bench","bird","cat",
                "dog","horse","sheep","cow","elephant","bear","zebra","giraffe","backpack",
                "umbrella","handbag","tie","suitcase","frisbee","skis","snowboard","sportsball",
                "kite","baseballbat","baseballglove","skateboard","surfboard","tennisracket",
                "bottle","wineglass","cup","fork","knife","spoon","bowl","banana","apple",
                "sandwich","orange","broccoli","carrot","hotdog","pizza","donut","cake","chair",
                "sofa","pottedplant","bed","diningtable","toilet","tvmonitor","laptop","mouse",
                "remote","keyboard","cellphone","microwave","oven","toaster","sink","refrigerator",
                "book","clock","vase","scissors","teddybear","hairdrier","toothbrush"]
```


```python
#Declare List of colors as an array
#Green, Blue, Red, cyan, yellow, purple
#Split based on ',' and for every split, change type to int
#convert that to a numpy array to apply color mask to the image numpy array
class_colors = ["0,255,0","0,0,255","255,0,0","255,255,0","0,255,255"]
class_colors = [np.array(every_color.split(",")).astype("int") for every_color in class_colors]
class_colors = np.array(class_colors)
class_colors = np.tile(class_colors,(16,1))

```


```python
# download cfg and weights file form Yolo site
!wget https://hr-projects-assets-prod.s3.amazonaws.com/ebch7d568km/e2f84d7d26826cfe43e8c9238cf110f7/yolov3.cfg
!wget https://pjreddie.com/media/files/yolov3.weights
```

    --2022-01-11 13:07:15--  https://hr-projects-assets-prod.s3.amazonaws.com/ebch7d568km/e2f84d7d26826cfe43e8c9238cf110f7/yolov3.cfg
    Resolving hr-projects-assets-prod.s3.amazonaws.com (hr-projects-assets-prod.s3.amazonaws.com)... 52.217.77.244
    Connecting to hr-projects-assets-prod.s3.amazonaws.com (hr-projects-assets-prod.s3.amazonaws.com)|52.217.77.244|:443... connected.
    HTTP request sent, awaiting response... 200 OK
    Length: 8342 (8.1K) [binary/octet-stream]
    Saving to: ‘yolov3.cfg’
    
    yolov3.cfg          100%[===================>]   8.15K  --.-KB/s    in 0s      
    
    2022-01-11 13:07:16 (51.6 MB/s) - ‘yolov3.cfg’ saved [8342/8342]
    
    --2022-01-11 13:07:17--  https://pjreddie.com/media/files/yolov3.weights
    Resolving pjreddie.com (pjreddie.com)... 128.208.4.108
    Connecting to pjreddie.com (pjreddie.com)|128.208.4.108|:443... connected.
    HTTP request sent, awaiting response... 200 OK
    Length: 248007048 (237M) [application/octet-stream]
    Saving to: ‘yolov3.weights’
    
    yolov3.weights      100%[===================>] 236.52M  13.3MB/s    in 19s     
    
    2022-01-11 13:07:37 (12.3 MB/s) - ‘yolov3.weights’ saved [248007048/248007048]
    



```python
# Loading pretrained model use openCV "dnn.readNetFromDarknet" function 
# input preprocessed blob into model and pass through the model
# obtain the detection predictions by the model using forward() method
yolo_model = cv2.dnn.readNetFromDarknet('yolov3.cfg','yolov3.weights')

```


```python
# Get all layers from the yolo network
# Loop and find the last layer (output layer) of the yolo network 
yolo_layers = yolo_model.getLayerNames()
yolo_output_layer = yolo_model.getUnconnectedOutLayersNames()  
```


```python
# input preprocessed blob into model and pass through the model
yolo_model.setInput(img_blob)
# obtain the detection layers by forwarding through till the output layer
obj_detection_layers = yolo_model.forward(yolo_output_layer)

```


```python
# initialization for non-max suppression (NMS)
# declare list for [class id], [box center, width & height[], [confidences]
class_ids_list = []
boxes_list = []
confidences_list = []
```


```python
# loop over each of the layer outputs
for object_detection_layer in obj_detection_layers:
    # loop over the detections
    for object_detection in object_detection_layer:
        # obj_detections[1 to 4] => will have the two center points, box width and box height
        # obj_detections[5] => will have scores for all objects within bounding box
        all_scores = object_detection[5:]
        predicted_class_id = np.argmax(all_scores)
        prediction_confidence = all_scores[predicted_class_id]
    
        # take only predictions with confidence more than 20%
        if prediction_confidence > 0.20:
            #get the predicted label
            predicted_class_label = class_labels[predicted_class_id]
            
            #obtain the bounding box co-oridnates for actual image from resized image size
            bounding_box = object_detection[0:4] * np.array([img_width, img_height, img_width, img_height])
            (box_center_x_pt, box_center_y_pt, box_width, box_height) = bounding_box.astype("int")
            start_x_pt = int(box_center_x_pt - (box_width / 2))
            start_y_pt = int(box_center_y_pt - (box_height / 2))
            

            #save class id, start x, y, width & height, confidences in a list for nms processing
            #make sure to pass confidence as float and width and height as integers
            class_ids_list.append(predicted_class_id)
            confidences_list.append(float(prediction_confidence))
            boxes_list.append([start_x_pt, start_y_pt, int(box_width), int(box_height)])

```


```python
q = []

# Applying the NMS will return only the selected max value ids while suppressing the non maximum (weak) overlapping bounding boxes      
# Non-Maxima Suppression confidence set as 0.5 & max_suppression threhold for NMS as 0.4 (adjust and try for better perfomance)
max_value_ids = cv2.dnn.NMSBoxes(boxes_list, confidences_list, 0.5, 0.4)

# loop through the final set of detections remaining after NMS and draw bounding box and write text
for max_valueid in max_value_ids:
    max_class_id = max_valueid
    box = boxes_list[max_class_id]
    start_x_pt = box[0]
    start_y_pt = box[1]
    box_width = box[2]
    box_height = box[3]
    
    #get the predicted class id and label
    predicted_class_id = class_ids_list[max_class_id]
    predicted_class_label = class_labels[predicted_class_id]
    prediction_confidence = confidences_list[max_class_id]

           
    end_x_pt = start_x_pt + box_width
    end_y_pt = start_y_pt + box_height
    
    #get a random mask color from the numpy array of colors
    box_color = class_colors[predicted_class_id]
    
    #convert the color numpy array as a list and apply to text and box
    box_color = [int(c) for c in box_color]
    
    # print the prediction in console
    predicted_class_label = "{}: {:.2f}%".format(predicted_class_label, prediction_confidence * 100)
    print("predicted object {}".format(predicted_class_label))
    q.append(predicted_class_label) 
    
    # draw rectangle and text in the image
    cv2.rectangle(img_to_detect, (start_x_pt, start_y_pt), (end_x_pt, end_y_pt), box_color, 1)
    cv2.putText(img_to_detect, predicted_class_label, (start_x_pt, start_y_pt-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, box_color, 1)

# cv2.imshow("Detection Output", img_to_detect)
```

    predicted object car: 98.84%
    predicted object person: 96.23%
    predicted object car: 93.10%
    predicted object car: 92.94%
    predicted object truck: 92.51%
    predicted object car: 86.02%
    predicted object motorcycle: 72.38%


> 
    Sample output
    predicted object car: 99.14%
    predicted object person: 98.43%
    predicted object car: 97.37%
    predicted object car: 95.33%


```python
# Display the output
cv2.imwrite("Detection Output.jpg", img_to_detect)
im = cv2.imread("Detection Output.jpg", 1)
im2 = im[:,:,::-1]
plt.imshow(im2,interpolation='nearest',aspect='auto')
plt.show()
```


    
![png](output_15_0.png)
    



```python
# IMP: please run the below cell for submitting the pickle file
print(q)
output = open('submit.pkl', 'wb')
pickle.dump(q, output)
output.close()
```

    ['car: 98.84%', 'person: 96.23%', 'car: 93.10%', 'car: 92.94%', 'truck: 92.51%', 'car: 86.02%', 'motorcycle: 72.38%']



```python
# Try to check your score
!python test_yolo.py
```

    FS_SCORE:100.0%



```python

```
